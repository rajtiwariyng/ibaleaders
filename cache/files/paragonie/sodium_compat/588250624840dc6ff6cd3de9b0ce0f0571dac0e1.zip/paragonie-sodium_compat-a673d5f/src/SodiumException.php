<?php
declare(strict_types=1);

if (class_exists('SodiumException', false)) {
    return;
}
/**
 * Class SodiumException
 */
class SodiumException extends Exception
{

}
